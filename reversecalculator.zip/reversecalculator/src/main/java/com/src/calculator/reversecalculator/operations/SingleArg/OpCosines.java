package com.src.calculator.reversecalculator.operations.SingleArg;

import java.math.BigDecimal;

public class OpCosines implements IOperationSingleArg{

	public BigDecimal apply(BigDecimal bdParam) {
		return new BigDecimal(Math.cos(Math.toRadians(bdParam.doubleValue())));
	}

}
