package com.src.calculator.reversecalculator.operations.MultiArg;

import java.math.BigDecimal;

public class OpAverage implements IOperationMultiArg {

	public BigDecimal apply(BigDecimal bdFirstParam, BigDecimal bdSecondParam) {
		return bdFirstParam.add(bdSecondParam).divide(new BigDecimal(2));
	}

}
