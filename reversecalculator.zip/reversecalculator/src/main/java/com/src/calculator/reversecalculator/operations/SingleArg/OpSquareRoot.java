package com.src.calculator.reversecalculator.operations.SingleArg;

import java.math.BigDecimal;

public class OpSquareRoot implements IOperationSingleArg {

	public BigDecimal apply(BigDecimal bdParam) {
		return new BigDecimal(Math.sqrt(bdParam.doubleValue()));

	}

}
