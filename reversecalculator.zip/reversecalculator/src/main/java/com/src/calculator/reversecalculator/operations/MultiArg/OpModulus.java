package com.src.calculator.reversecalculator.operations.MultiArg;

import java.math.BigDecimal;

public class OpModulus implements IOperationMultiArg {

	public BigDecimal apply(BigDecimal bdFirstParam, BigDecimal bdSecondParam) {
		return bdFirstParam.remainder(bdSecondParam);
	}

}
