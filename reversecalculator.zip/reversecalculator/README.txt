This project is developed By Nagayya as part of Capgemini technical test. 

How to run:
1) Please unzip the file "reversecalculator.zip" into folder.
2) You can directly import this unzipped folder into Eclipse environment.
3) The input file can be either passed to main class or you can just edit the default input file
present in the resource folder "CalculationInput.txt". You can copy and paste the input text in this default file.
3) Java classs with Main methid is: StartCalculaterApp.
4) You can open this file directly in eclipse and run it from eclipse. It will take default input file "CalculationInput.txt"


Few observations:
1) For the invalid input, it will throw error and will not produce partial output.
2) There are testcases for both positive and negative scenario's.
3) To run test cases and build the code, you can run the standard maven command:
mvn clean install
4) it uses command design pattern to find which operation to run.
5) there is no limit to number (or decimal points) as i have used Java BigDecimal for all calculations.
6) It uses Big O(n2), one outer loop for number of lines and another inner loop for calculations within each line. There is another loop for validation but that can be removed.