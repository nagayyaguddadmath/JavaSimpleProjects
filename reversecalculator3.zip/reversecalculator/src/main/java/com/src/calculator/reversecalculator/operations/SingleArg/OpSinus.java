package com.src.calculator.reversecalculator.operations.SingleArg;

import java.math.BigDecimal;

public class OpSinus implements IOperationSingleArg  {

	public BigDecimal apply(BigDecimal bdParam) {
		return new BigDecimal(Math.sin(Math.toRadians(bdParam.doubleValue())));
		
	}

}
