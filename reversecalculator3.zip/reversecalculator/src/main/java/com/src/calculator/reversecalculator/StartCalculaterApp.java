package com.src.calculator.reversecalculator;

import java.io.IOException;
import java.util.List;

public class StartCalculaterApp 
{
	//Path of file can be taken from either command line arguments OR
	// can be taken from pre-defined location (from resource folder)
	private static final String strPathOfFile = System.getProperty("user.dir") + 
			"\\src\\main\\resources\\" + "CalculationInput.txt";

	public static void main( String[] args ) throws IOException
	{
		//argument can have path of the file that needs to be calculated
		List<String> inputList = InputFileRead.readFile(args.length == 0 ? strPathOfFile : args[0]);

		//we can do multi threading (doing calculations in chunks) if the file is very large
		//For mediam sized files, this should work 
		CalculateCommands calculateAll = new CalculateCommands();
		List<String> outputList = calculateAll.calculateAll(inputList);
		for (String line : outputList) {
			System.out.println(line);
		}

	}
}
