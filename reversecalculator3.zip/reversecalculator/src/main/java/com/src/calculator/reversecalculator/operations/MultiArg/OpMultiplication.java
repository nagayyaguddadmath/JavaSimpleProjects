package com.src.calculator.reversecalculator.operations.MultiArg;

import java.math.BigDecimal;

public class OpMultiplication implements IOperationMultiArg {

	public BigDecimal apply(BigDecimal firstParam, BigDecimal secondParam) {
		return firstParam.multiply(secondParam);

		
	}

}
