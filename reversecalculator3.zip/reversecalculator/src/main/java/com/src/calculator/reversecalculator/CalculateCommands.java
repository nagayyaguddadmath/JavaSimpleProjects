package com.src.calculator.reversecalculator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.src.calculator.reversecalculator.operations.MultiArg.*;
import com.src.calculator.reversecalculator.operations.SingleArg.*;

/*
 * This uses Command pattern to calculate
 * 
 */
public class CalculateCommands {

	private static final Map<String, IOperationMultiArg> multiArgCommands;

	private static final Map<String, IOperationSingleArg> singleArgCommands;

	//below parameters can be put in property file for good maintanability
	private static final String delimitor = "\\s";

	private static final String invalidStr = " - Not Reverse Polish Notation try backwards";

	static {
		//we can add new operations just by creating new operation classes and adding it to below maps
		multiArgCommands = new HashMap<String, IOperationMultiArg>();
		multiArgCommands.put("+", new OpAddition());
		multiArgCommands.put("-", new OpMinus());
		multiArgCommands.put("/", new OpDivision());
		multiArgCommands.put("*", new OpMultiplication());
		multiArgCommands.put("avg", new OpAverage());
		multiArgCommands.put("mod", new OpModulus());

		singleArgCommands = new HashMap<String, IOperationSingleArg>();
		singleArgCommands.put("sin", new OpSinus());
		singleArgCommands.put("cos", new OpCosines());
		singleArgCommands.put("sqrt", new OpSquareRoot());

	}

	//This is main method to do all calculations
	public List<String> calculateAll (List<String> inputList) {

		List<String> outputList = new ArrayList<String>();
		int lineIndex = 0;
		for (String line : inputList) {
			calculateEachLine(line, lineIndex, inputList, outputList);
			lineIndex++;

		}
		return outputList;
	}

	//Calculations for each line
	private void calculateEachLine(String line, int lineIndex, List<String> inputList, List<String> outputList) {
		String[] args = line.split(delimitor);
		validateEachLine(args, lineIndex);
		if (args.length < 1 ) {
			outputList.add(inputList.get(lineIndex).concat(invalidStr));
		} else if (args.length == 1 ) {
			calculateIfLineHasOneOp(args[0], lineIndex, inputList, outputList);
		} else {
			BigDecimal bdNextValue = null;
			BigDecimal bdCurrentCalc =new BigDecimal(args[0]);;
			int i = 1;
			boolean erroredLine = false;

			do {
				if (singleArgCommands.get(args[i]) != null) {
					if (bdNextValue == null) {
						bdCurrentCalc  = applyOperationSingle(bdCurrentCalc, singleArgCommands.get(args[i]));
					} else {
						erroredLine = true;
						break;
					}
				} else if (multiArgCommands.get(args[i]) != null) {
					if (bdNextValue == null) {
						erroredLine = true;
						break;
					}
					bdCurrentCalc  = applyOperationMulti(bdCurrentCalc, bdNextValue, multiArgCommands.get(args[i]));
					bdNextValue = null;
				} else {
					bdNextValue = new BigDecimal(args[i]);
				}
				i++;
			} while (i < args.length);
			outputList.add( erroredLine  ? inputList.get(lineIndex).concat(invalidStr) : inputList.get(lineIndex).concat(" = ".concat(bdCurrentCalc.toString())));
		}		
	}


	private void calculateIfLineHasOneOp(String arg, int lineIndex, List<String> inputList, List<String> outputList) {
		if(singleArgCommands.get(arg) != null || multiArgCommands.get(arg) != null) {
			outputList.add(inputList.get(lineIndex).concat(invalidStr));
		} else {
			outputList.add(inputList.get(lineIndex).concat("=".concat(arg)));
		}

	}

	private void validateEachLine(String[] args, int lineIndex) {
		for (String arg : args) {
			if ( !( multiArgCommands.get(arg) != null || singleArgCommands.get(arg) != null ||
					arg.matches("[-+]?\\d*\\.?\\d+") ) ) {
				String error = "ERROR: Invalid File Content at line number " + lineIndex + ". This value '" + arg + "' is not allowed in line:" + String.join(" ", args);
				System.out.println(error);
				throw new IllegalArgumentException(error);
			}
		}

	}

	private BigDecimal applyOperationSingle(BigDecimal param, IOperationSingleArg operation) {
		return operation.apply(param);
	}

	private BigDecimal applyOperationMulti(BigDecimal param1, BigDecimal param2, IOperationMultiArg operation) {
		return operation.apply(param1,  param2);
	}

}
