package com.src.Checkout;

import java.util.ArrayList;
import java.util.List;

import com.src.checkout.Checkout;
import com.src.checkout.product.Product;
import com.src.checkout.product.PurchasedProduct;
import com.src.checkout.promotions.IPromotionRule;
import com.src.checkout.promotions.ItemBasedPromotionRule;
import com.src.checkout.promotions.TotalAmountPromotionRule;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for Checkout App.
 */
public class CheckoutTest extends TestCase
{

	private static List<Product> products = new ArrayList<Product>();
	private List<IPromotionRule> promotionalRules = new ArrayList<IPromotionRule>();

	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	public CheckoutTest( String testName )
	{
		super( testName );

		promotionalRules.add(new ItemBasedPromotionRule("001", 2, 8.5));
		promotionalRules.add(new TotalAmountPromotionRule(60d, 10d));

		products.add(new Product("001", "Travel Card Holder", 9.25d));
		products.add(new Product("002", "Personalised cufflinks", 45.00d));
		products.add(new Product("003", "Kids T-shirt", 19.95d));
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite()
	{
		return new TestSuite( CheckoutTest.class );
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testPromotionApplying1()
	{
//		Testing for Basket: 001,002,003 ::
		Checkout checkout1 = new Checkout(promotionalRules);
		PurchasedProduct item1 = new PurchasedProduct(products.get(0));
		PurchasedProduct item2 = new PurchasedProduct(products.get(1));
		PurchasedProduct item3 = new PurchasedProduct(products.get(2));

		//Basket: 001,002,003 ::
		checkout1.scan(item1);
		checkout1.scan(item2);
		checkout1.scan(item3);
		assertEquals("Final amount is not matching..",66.78d, checkout1.total());
	}

	public void testPromotionApplying2()
	{
//		Testing for "Basket: 001,003,001 ::
		Checkout checkout2 = new Checkout(promotionalRules);
		PurchasedProduct item1 = new PurchasedProduct(products.get(0));
		PurchasedProduct item3 = new PurchasedProduct(products.get(2));
		PurchasedProduct item4 = new PurchasedProduct(products.get(0));

		//Basket: 001,003,001
		checkout2.scan(item1);
		checkout2.scan(item3);
		checkout2.scan(item4);
		assertEquals("Final amount is not matching..",36.95d, checkout2.total());

	}

	public void testPromotionApplying3()
	{
//		Testing for Basket: 001,002,001,003 ::
		Checkout checkout3 = new Checkout(promotionalRules);
		PurchasedProduct item1 = new PurchasedProduct(products.get(0));
		PurchasedProduct item2 = new PurchasedProduct(products.get(1));
		PurchasedProduct item3 = new PurchasedProduct(products.get(2));
		PurchasedProduct item4 = new PurchasedProduct(products.get(0));

		//Basket: 001,002,001,003 :: 
		checkout3.scan(item1);
		checkout3.scan(item2);
		checkout3.scan(item4);
		checkout3.scan(item3);
		assertEquals("Final amount is not matching..",73.76d, checkout3.total());
	}

}
