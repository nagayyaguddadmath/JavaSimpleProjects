package com.src.checkout.promotions;

import java.util.Set;

import com.src.checkout.product.PurchasedProduct;

public interface IPromotionRule {

	public double apply(Set<PurchasedProduct> products);

}