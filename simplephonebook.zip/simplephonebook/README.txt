Hi,

This application is based on 
Server side (back end): spring boot, Rest services and maven 
Client side (front end): AngularJS, HTML

To run and test this:
You need to deploy file "simplephonebook-0.0.1-SNAPSHOT.war" present in target folder, in TOMCAT (or any) web server 
OR you can run using spring Boot also

The Page to open is in local machine is:
http://localhost:8080/phonebook.html

Server is exposing below web services:
addContact
addContacts
removeContact
getContactByName
searchContacts
sortByName
updateContact
getFirstSerachByName
getAll

If you want to test backend web services :
Also you can test backend rest services, you can use postman tool and I have stored all 
Postman Requests Link in below link. You can copy these requests
https://www.getpostman.com/collections/7c187ce2159ac60769ed

I have not yet written JUNITS as it was not mandatory for assignment

Please let me know for any questions.


