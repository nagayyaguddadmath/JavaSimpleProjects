package com.phonebook.simplephonebook.validate;

public class ValidateContact {

}
