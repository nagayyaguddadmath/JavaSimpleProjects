package com.src.calculator.reversecalculator;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class InputFileRead {
	
	private static final Charset encoding = Charset.defaultCharset();

	public static List<String> readFile(String pathOfFile) throws IOException {
		
		try {
			return  Files.readAllLines(Paths.get(pathOfFile), encoding);
		} catch (IOException e) {
			System.out.println("Error occurred while reading file. Error is:" + e.getMessage());
			e.printStackTrace();
			throw e;
		}
		
	}
}
