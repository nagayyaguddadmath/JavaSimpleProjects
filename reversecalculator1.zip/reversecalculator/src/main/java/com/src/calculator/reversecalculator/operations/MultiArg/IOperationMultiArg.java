package com.src.calculator.reversecalculator.operations.MultiArg;

import java.math.BigDecimal;

/*
 * This is interface for operations with more than one parameters
 * Later this interface can be extended for more than 
 * two parameter if needed
 */
public interface IOperationMultiArg {

	public BigDecimal apply(BigDecimal bdFirstParam, BigDecimal bdSecondParam);
}
