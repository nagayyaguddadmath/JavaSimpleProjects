package com.src.calculator.reversecalculator.operations.SingleArg;

import java.math.BigDecimal;

public interface IOperationSingleArg {

	public BigDecimal apply(BigDecimal bdParam);
}
