package com.src.calculator.reversecalculator.operations.MultiArg;

import java.math.BigDecimal;

public class OpDivision implements IOperationMultiArg {

	public BigDecimal apply(BigDecimal firstParam, BigDecimal secondParam) {
		return firstParam.divide(secondParam, 11, BigDecimal.ROUND_HALF_UP);
		
	}

}
