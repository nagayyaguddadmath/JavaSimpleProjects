package com.src.calculator.reversecalculator;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class CalculatorTest extends TestCase
{
	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	public CalculatorTest( String testName )
	{
		super( testName );
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite()
	{
		return new TestSuite( CalculatorTest.class );
	}

	public void testForCorrectValues()
	{
		String strPathOfInputFile = System.getProperty("user.dir") + 
				"\\src\\test\\resources\\input\\" + "TestCalculationCorrect_1.txt";

		String strPathOfOutputFile = System.getProperty("user.dir") + 
				"\\src\\test\\resources\\output\\" + "TestOutputCorrect_1.txt";

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		PrintStream old = System.out;
		System.setOut(ps);

		try {
			StartCalculaterApp.main(new String[] {strPathOfInputFile});

			byte[] encoded = Files.readAllBytes(Paths.get(strPathOfOutputFile));

			assertEquals("Wrong calculation", new String(encoded, Charset.defaultCharset()), baos.toString());

		} catch (IOException e) {
			assertTrue("Error should not have occurred. Error was:" + e.getMessage(), false);
		} finally {
			System.out.flush();
			System.setOut(old);

		}
	}


	public void testForIncorrectValues()
	{
		String strPathOfInputFile = System.getProperty("user.dir") + 
				"\\src\\test\\resources\\input\\" + "TestCalculationWrong_1.txt";

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		PrintStream old = System.out;
		System.setOut(ps);
		try {

			StartCalculaterApp.main(new String[] {strPathOfInputFile});

			assertTrue("Should have thrown error as input was wrong", false);

		} catch (IOException e) {
			assertTrue("Error should not have occurred. Error was:" + e.getMessage(), false);
		} catch (IllegalArgumentException e) {
			assertTrue("IllegalArgumentException error should have throws this message", e.getMessage().equals(
					"ERROR: Invalid File Contents. This value 'testFail' is not allowed in line:4 2 - 2 - 1000 testFail"));
		} finally {
			System.out.flush();
			System.setOut(old);

		}
	}

}
