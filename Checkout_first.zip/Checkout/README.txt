This code is for the Checkout Products assignment developed by Nagayya

This is maven based project and you can test this by opening project in editor (eclipse) and just run the test class "CheckoutTest"



Few important observations:
1) Checkout is main class that will do the scanning and checkout. It will apply promotions in the same order as they are added to list.
this can be changed if needed by adding priority order to the promotion object.
2) There are two types of promotion classes, one promotion will apply given discount on the total amount. Anither class applies discount on items.
These two classes are quite generic in natare so that we can create more such rules. We can add disount on any items. 
Also we can implement more new promotionRules by implementing interface IPromotionRule
3) the field afterDiscountPrice present in class Product stores the original price by default and After applying each promotion, price will be reduced.
Final (total) discount will be applied on afterDiscountPrice (not the orginal price)




This has 5 JUNITS in two test files and second test class is having my own promotion rules just for testing purpose
First test class will test the below 3 scenarios:
Test data
Basket: 001,002,003 :: 
Total price expected: �66.78

Basket: 001,003,001 :: 
Total price expected: �36.95

Basket: 001,002,001,003 :: 
Total price expected: �73.76
in this scenario, if we swap the promotion order then total will become 73.61, which is wrong