package com.src.checkout.product;

public class PurchasedProduct extends Product {

	private int countOfPuchased = 0;
	private double afterDiscountPrice;

	public PurchasedProduct(Product product) {
		super(product.getProductCode(), product.getName(), product.getOriginalPrice());
		//by default, there is no discount
		this.setAfterDiscountPrice(product.getOriginalPrice());
	}

	public int getCountOfPuchased() {
		return countOfPuchased;
	}

	//parameter option has been given to increase count for bulk buy
	public void increaseCountBy(int countOfPuchased) {
		this.countOfPuchased += countOfPuchased;
	}


	public double getAfterDiscountPrice() {
		return afterDiscountPrice;
	}

	public void setAfterDiscountPrice(double afterDiscountPrice) {
		this.afterDiscountPrice = afterDiscountPrice;
	}

}
