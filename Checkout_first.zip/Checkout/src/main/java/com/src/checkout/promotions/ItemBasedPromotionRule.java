package com.src.checkout.promotions;

import java.util.Set;

import com.src.checkout.product.PurchasedProduct;

public class ItemBasedPromotionRule implements IPromotionRule {

	private String productCode;
	private int minCountNeeded;
	private double priceAfterDiscount;

	public ItemBasedPromotionRule(String productCode, int minCountNeeded, double discountInPerc) {
		this.productCode = productCode;
		this.minCountNeeded = minCountNeeded;
		this.priceAfterDiscount = discountInPerc;
	}

	@Override
	public double apply(Set<PurchasedProduct> products) {
		PurchasedProduct foundProduct = products.stream().filter(p -> p.getProductCode().equals(productCode)).findFirst().orElse(null);
		//found product should be only one as we use set collection type
		double totalDiscountApplied = 0.0;
		if (foundProduct != null) {
			if (((PurchasedProduct)foundProduct).getCountOfPuchased() >= minCountNeeded) {
				//below line is ot get discount per item
				totalDiscountApplied =  foundProduct.getOriginalPrice() - priceAfterDiscount;
				foundProduct.setAfterDiscountPrice(foundProduct.getAfterDiscountPrice() - totalDiscountApplied);
				//below is to get total discount for all found items
				totalDiscountApplied = totalDiscountApplied * ((PurchasedProduct)foundProduct).getCountOfPuchased();
			}
		}
		return totalDiscountApplied;
	}

}
