to execute this application:
1) Please unzar the file into some folder
2) Open console and execute below command in the fodler "quote"
3) Rename quote.jar.txt to quote.jar
and then execute:

java -cp quote.jar com.MainApplication "C:\Users\nagayya\Documents\GitHub\SampleLearning\quote\market.csv" 1000

How it will calculate interest:
1) Sorts all lenders by low interest and then high amount
2) Calculates mean interest rate by giving waightage to the amount each lender is giving
3) Calculates average interest rate
4) From average interest rate , it will calculate total amount