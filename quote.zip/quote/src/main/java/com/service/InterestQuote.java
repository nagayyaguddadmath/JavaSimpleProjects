package com.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.Set;

import com.model.Lender;

public class InterestQuote {

	private Set<Lender> selectedLenders = new HashSet<Lender>();
	private BigDecimal monthlyRepayment;
	private BigDecimal interestApplied;

	public static final int NOOFMONTHS = 36;
	private static final int PERYEARCOMPOUND = 12;
	private int DIVIDEROUNDING = 10;

	public Set<Lender> getSelectedLenders() {
		return selectedLenders;
	}

	public BigDecimal getMonthlyRepayment() {
		return monthlyRepayment;
	}

	public boolean calculateInterestQuote(BigDecimal initalAmount, Set<Lender> lendersList) {
		selectLenders(initalAmount, lendersList);
		BigDecimal ratePerMonth = getAverageLendersRate(initalAmount);//new BigDecimal(Math.round((selectedLenders.stream().mapToDouble(l ->l.getRateOfInterest().doubleValue()).average().orElse(100.0)) * 100.0)/100.0);
		monthlyRepayment = calculateInterest(initalAmount, ratePerMonth);
//		BigDecimal interestNoPayment = calculateOnlyInterest(new BigDecimal(480), new BigDecimal(0.069));
		return true;
	}

	private BigDecimal calculateInterest(BigDecimal initalAmount, BigDecimal ratePerMonth) {

		return
				(initalAmount.multiply(ratePerMonth)).divide(
						BigDecimal.valueOf(1-Math.pow(ratePerMonth.add(BigDecimal.ONE).doubleValue(), -NOOFMONTHS)),
						DIVIDEROUNDING, RoundingMode.HALF_UP);


	}

	private BigDecimal calculateOnlyInterest(BigDecimal initalAmount, BigDecimal ratePerMonth) {
		return  initalAmount.
				multiply(
						BigDecimal.ONE.
						add(
								ratePerMonth.
								divide(
										new BigDecimal(PERYEARCOMPOUND), DIVIDEROUNDING, RoundingMode.HALF_UP
										)
								).pow( (19))//NOO19FMONTHS) )
						);

	}

	private void selectLenders(BigDecimal initalAmount, Set<Lender> lendersList) {
		for (Lender lender: lendersList) {
			int compare = initalAmount.compareTo(lender.getAmount());
			if (compare <= 0) {
				selectedLenders.add(new Lender(lender, initalAmount));
				return;
			} else {
				selectedLenders.add(new Lender(lender, lender.getAmount()));
				initalAmount = initalAmount.subtract(lender.getAmount());
			}
		}
		if (initalAmount.compareTo(BigDecimal.ZERO) > 0) {
			throw new IllegalArgumentException("Market does not have sufficient offers from lenders to satisfy the loan");
		}
	}

	public BigDecimal getAverageLendersRate(BigDecimal initalAmount) {
		BigDecimal[] totalWithCount
		= selectedLenders.stream()
		.filter(l -> l.getRateOfInterest() != null)
		.map(l -> new BigDecimal[]{l.getRateOfInterest().multiply(l.getAmount().divide(initalAmount, DIVIDEROUNDING, RoundingMode.HALF_UP)), BigDecimal.ONE})
		.reduce((a, b) -> new BigDecimal[]{a[0].add(b[0]), a[1].add(BigDecimal.ONE)})
		.get();

		interestApplied = totalWithCount[0];//.divide(totalWithCount[1], DIVIDEROUNDING, RoundingMode.HALF_UP);
		return interestApplied.divide(BigDecimal.valueOf(12), DIVIDEROUNDING, RoundingMode.HALF_UP);
		//		return  totalWithCount[0].divide(totalWithCount[1], DIVIDEROUNDING, RoundingMode.HALF_UP);
	}

	public BigDecimal getInterestApplied() {
		return interestApplied;
	}
}
