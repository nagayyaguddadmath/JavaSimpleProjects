package com;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Set;

import com.model.Lender;
import com.service.InterestQuote;
import com.service.ReadMarkerFile;

public class MainApplication {


	public static void main(String[] args) throws IOException, ParseException {

		validateArgParams(args);
//		final String inputfilePath = MainApplication.class.getResource("resources/market.csv").getFile();

		ReadMarkerFile readFile = new ReadMarkerFile();
		Set<Lender> lenders = readFile.readLenderFromFile(args[0]);
		InterestQuote quote = new InterestQuote();
		BigDecimal initalAmount = new BigDecimal(args[1]);
		quote.calculateInterestQuote(initalAmount, lenders);

		printQuote(quote, initalAmount);
	}

	private static void printQuote(InterestQuote quote, BigDecimal initalAmount) {
		System.out.println("Requested amount: �" + initalAmount.toString());
		System.out.println("Rate: " + quote.getInterestApplied().multiply(BigDecimal.valueOf(100)).setScale(1, BigDecimal.ROUND_HALF_UP) + "%");
		System.out.println("Monthly repayment:" + quote.getMonthlyRepayment().setScale(2, BigDecimal.ROUND_HALF_UP));
		System.out.println("Total repayment:" + quote.getMonthlyRepayment().multiply(BigDecimal.valueOf(InterestQuote.NOOFMONTHS)).setScale(2, BigDecimal.ROUND_HALF_UP));
	}

	private static void validateArgParams(String[] args) {
		if (args.length != 2) {
			throw new IllegalArgumentException("Not a valid argument: "+args); 
		}
		try {
			BigDecimal amount = new BigDecimal(args[1]);
			if (amount.compareTo(BigDecimal.valueOf(1000)) < 0 || amount.compareTo(BigDecimal.valueOf(15000)) > 0 ||
					!amount.remainder(BigDecimal.valueOf(100)).equals(BigDecimal.ZERO)) {
				throw new IllegalArgumentException("Not a valid amount: "+amount.toString()); 
			}
		} catch(NumberFormatException e) {
			throw new IllegalArgumentException("Not a valid argument: "+args[1]); 
		}
	}

}
